

base_url = 'https://brij-tech.herokuapp.com/'
tokens = 'api/tokens'
mpesa_to_acc_url = 'api/mpesa-to-acc'
mpesa_to_escrow_url = 'api/mpesa-to-escrow'